﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_9_30_24_formatting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //  decimal round= decimal.Parse(textBox1.Text);  this will error
            decimal round;
            if (decimal.TryParse(textBox1.Text, out round));
            {
                round = decimal.Round(round,2, MidpointRounding.AwayFromZero);
                textBox1.Text = round.ToString();
            }

        }
    }
}
