﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MS539_9_30_24_file_io
{
    public partial class Form1 : Form
    {
        string textFile = "jun.txt";
        public Form1()
        {
            InitializeComponent();
        }
        //your functions go here
        void display()
        {
            MessageBox.Show("The textbox says " + textBox1.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
         //   using (StreamWriter sw = new StreamWriter(textFile))//always c reate a new file
           using (StreamWriter sw = File.AppendText(textFile))//append if exists, create if not
            {
               sw.WriteLine(textBox1.Text);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (StreamReader sr = new StreamReader(textFile))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        MessageBox.Show(line);
                    }

                }
            }
            catch (Exception ex)
            { MessageBox.Show(ex.Message); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Choose a file for reading";
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.FileName = "All file (*.*)|text file (*.txt)|*.txt";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.ShowDialog();

            if (openFileDialog1.ShowDialog() == DialogResult.OK) 
            {
                string filePath = openFileDialog1.FileName;
                var fileStream = openFileDialog1.OpenFile();

                using (StreamReader reader = new StreamReader(filePath))
                { 
                    var fileContent = reader.ReadToEnd();
                    MessageBox.Show(fileContent);
                }


            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            display();
        }
    }
}
